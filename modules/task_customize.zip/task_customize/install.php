<?php

defined('BASEPATH') or exit('No direct script access allowed');

$my_projects_path = APPPATH . 'views/admin/tables/my_tasks.php';
$module_my_projects_path = module_dir_path(TASK_CUSTOMIZE_MODULE_NAME) . 'system_changes/task/my_tasks.php';
if (!file_exists($my_projects_path)) {
  copy($module_my_projects_path, $my_projects_path);
}


defined('BASEPATH') or exit('No direct script access allowed');

$my_projects_path = APPPATH . 'views/admin/tasks/my_view_task_template.php';
$module_my_projects_path = module_dir_path(TASK_CUSTOMIZE_MODULE_NAME) . 'system_changes/task/my_view_task_template.php';
if (!file_exists($my_projects_path)) {
  copy($module_my_projects_path, $my_projects_path);
}

$my_projects_path = APPPATH . 'views/admin/tables/my_projects.php';
$module_my_projects_path = module_dir_path(TASK_CUSTOMIZE_MODULE_NAME) . 'system_changes/my_projects.php';
if (!file_exists($my_projects_path)) {
  copy($module_my_projects_path, $my_projects_path);
}

//for projects
$my_manage_projects_path = APPPATH . 'views/admin/projects/my_manage.php';
$module_my_manage_projects_path = module_dir_path(TASK_CUSTOMIZE_MODULE_NAME) . 'system_changes/projects/my_manage.php';
if (!file_exists($my_manage_projects_path)) {
  copy($module_my_manage_projects_path, $my_manage_projects_path);
}

//for projects view
$my_projects_view_path = APPPATH . 'views/admin/projects/my_view.php';
$module_my_projects_view_path = module_dir_path(TASK_CUSTOMIZE_MODULE_NAME) . 'system_changes/projects/my_view.php';
if (!file_exists($my_projects_view_path)) {
  copy($module_my_projects_view_path, $my_projects_view_path);
}

//make table qury for projects_notes 
// CREATE TABLE `tblprojects_notes` (
//   `id` int(11) NOT NULL AUTO_INCREMENT,
//   `content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
//   `project_id` int(11) NOT NULL,
//   `staffid` int(11) NOT NULL,
//   `contact_id` int(11) NOT NULL DEFAULT '0',
//   `file_id` int(11) NOT NULL DEFAULT '0',
//   `dateadded` datetime NOT NULL,
//   PRIMARY KEY (`id`),
//   KEY `file_id` (`file_id`),
//   KEY `project_id` (`project_id`)
// )
if (!$CI->db->table_exists(db_prefix() . 'projects_notes')) {
  $CI->db->query('CREATE TABLE `' . db_prefix() . 'projects_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_id` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=' . $CI->db->char_set . ';');
}


