

<table border="1" style="width:100%;height:55px;">
	<tbody>
		<tr style="height:27px;">
			<td style="width:25%;height:27px;text-align:left;"><strong>Salary/Allowance</strong></td>
			<td style="width:25%;height:27px;"><strong>Amount</strong></td>
			<td style="width:25%;height:27px;"><strong>Effective date</strong></td>
			<td style="width:25%;height:27px;"><strong>Note</strong></td>
		</tr>
		<tr style="height:28px;">
			<td style="width:25%;height:28px;"><span>AL1</span></td>
			<td style="width:25%;height:28px;"><span>1,000.00</span></td>
			<td style="width:25%;height:28px;"><span>2021-08-02</span></td>
			<td style="width:25%;height:28px;">aa</td>
		</tr>
	</tbody>
</table>